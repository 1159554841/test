//app.js
App({
  onLaunch: function(options) {
    console.log("onLaunch场景值:" + options.scene);
  },

  moneyCallback: function(msg) {
    if (msg.data.status == 1) {
      var money = msg.data.money;
      wx.setStorageSync("userAmount", money);
    }
  },

  onShow: function(options) {

    var userId  = wx.getStorageSync("userId");
    console.log("asasasas");
    console.log(userId);
    var scence = options.scene;
    console.log("onShow场景值:" + scence);
    var that = this;
    var param = {};
    param.id = 'addStatus';
    param.scence = scence;
    param.userId = wx.getStorageSync("userId");

    var openId = wx.getStorageSync("openId");
    if (openId) {

      var url = that.globalData.WXBaseUrl + "getByOpenId";

      var loginParam = {};
      loginParam.openId = openId;
      that.getHttpData(loginParam, url, that.authOpenId);

    }

    var key = "higame$$#@&u";
    var random = (Math.random(1) * Math.pow(10, 5)).toString().substring(0, 5);
    var str = param.userId + param.id + random + key;

    var length = str.length;
    var sign = Math.sqrt(length).toString().substring(0, 5);
    param.sign = sign;
    param.random = random;
    param.version = that.globalData.Version;

    var url = that.globalData.WXBaseUrl + "getScence";

    that.getHttpData(param, url, that.moneyCallback);
  },

  authOpenId: function(res) {
    console.log("getopenId")
    console.log(res)
    if (res.data.status == 1) {
      wx.setStorageSync('openId', res.data.openId); //保存openId
      wx.setStorageSync('userImg', res.data.avatarUrl); //保存用户头像
      wx.setStorageSync('userName', res.data.nickName.substring(0, 10)); //保存用户昵称
      wx.setStorageSync('userAmount', res.data.amount); //保存用户金币
      wx.setStorageSync('userId', res.data.userId); //保存用户userId
      //  obj.editUserinfo(); //回调函数

    }
  },


  // 向后台发送用户微信数据
  sendUserinfoData: function(e, obj) {
    var that = this;
    var openId = wx.getStorageSync('openId'); //openId
    console.log("openid==="+openId);

    if (!openId) {
      // 获取登录的code
      wx.login({
        success: function(res) {


          if (res.code) {
            wx.request({
              url: that.globalData.WXBaseUrl + "decode",
              data: {
                code: res.code,
                encryptedData: e.detail.encryptedData,
                iv: e.detail.iv
              },
              method: 'POST',
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              success: function(res) {
                console.log(111);
                console.log(res.data);
                wx.setStorageSync('openId', res.data.openId); //保存openId
                wx.setStorageSync('userImg', res.data.avatarUrl); //保存用户头像
                wx.setStorageSync('userName', res.data.nickName.substring(0, 10)); //保存用户昵称
                wx.setStorageSync('userAmount', res.data.amount); //保存用户金币
                wx.setStorageSync('userId', res.data.userId); //保存用户userId
                if(res.data.isFirst==1){
                  wx.setStorageSync('isFirst', 1);
                  var str ="恭喜您在首次登录时获得"+res.data.actvityAmount+"金币红包！";
                  that.showToast(str);
                }
                obj.editUserinfo(); //回调函数
              }
            })

          } else {
            console.log('没有code' + res.code);
          }
        }
      })
    }
  },


  // 向后台发送用户微信数据callback
  getUserRedPackage: function(e, callback) {
    var that = this;
    var openId = wx.getStorageSync('openId'); //openId

    if (!openId) {
      // 获取登录的code
      wx.login({
        success: function(res) {
          if (res.code) {
            var data = {
              code: res.code,
              encryptedData: e.detail.encryptedData,
              iv: e.detail.iv
            };
            console.log("deoce")
            console.log(data);

            var url = that.globalData.WXBaseUrl + "decode";
            that.getHttpData(data, url, callback);
          } else {
            console.log('没有code' + res.code);
          }

        },

      })
    }
  },


  showToast: function(title) {

    wx.showToast({
      title: title,
      icon: 'none',
      duration: 2100
    })
  },


  onGotUserInfo: function(e) {},

  //字符串转换成对象
  stringToObject: function(str) {
    if (str == '' || str == null) {
      return str;
    }
    var obj = {};
    var arr = str.split("|");


    var k, v, sub;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] !== '') {
        sub = arr[i].split("=");
        if (sub !== '') {
          k = sub[0];
          v = sub[1];

          if (k !== '') {
            obj[k] = v;
          }
        }
      }
    }
    return obj;
  },

  //三维数组
  thirdArrFormat: function(data) {

    var that = this;
    if (data == null || data == '') {
      return data;
    }

    for (var i = 0; i < data.length; i++) {
      for (var j = 0; j < data[i].data.length; j++) {
        data[i].data[j].param = that.stringToObject(data[i].data[j].param);
        data[i].data[j].pathUrl = data[i].data[j].pathUrl.toString().replace("|", "&");
      }
    }
    return data;
  },


  //二维数组转化
  twoArrFormat: function(data) {
    var that = this;
    if (data == null || data == '') {
      return data;
    }

    for (var i = 0; i < data.length; i++) {
      data[i].param = this.stringToObject(data[i].param);
      data[i].pathUrl = data[i].pathUrl.toString().replace("|", "&");
    }
    return data;
  },




  //请求参数
  getHttpData: function(param, url, callback) {
    wx.request({
      url: url,
      data: param,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function(msg) {
        callback(msg);
      },
      fail: function(msg) {},
    })
  },

  globalData: {
    WXBaseUrl: "https://gamebox.muzigame.com/index.php?g=H5Api&m=Api&a=", //后台的基本接口
    WXbackgroundImgUrl: "http://gamebox.muzigame.com/public/images/icon/", //背景图的基本路径
    Version: "1.1.0", //版本号
  },

})