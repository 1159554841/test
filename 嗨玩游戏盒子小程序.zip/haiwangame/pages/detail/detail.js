// pages/detail/detail.js
var WxParse = require('../wxParse/wxParse.js');

const app=getApp();
//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    contentDetailUrl: BASEURL +"getContentById"
  },  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     var id=options.id;
     
    // WxParse.wxParse('article', 'html', article, this, 5);
    var param={};
    param.id=id;
    param.userId=wx.getStorageSync("userId");
    console.log(param);
    app.getHttpData(param,this.data.contentDetailUrl, this.contentCallback)
  },

  //获取文章的数据
  contentCallback:function(msg){

    var content=msg.data.data.des;
    WxParse.wxParse('article', 'html', content, this, 5);
  },
  //返回到社区
  goBack:function(){

    wx.switchTab({
      url: '../../pages/community/community',
      fail: function (msg) {
        console.log(msg)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

})