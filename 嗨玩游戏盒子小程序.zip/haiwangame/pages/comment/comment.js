// pages/comment/comment.js
const upng = require('../../utils/UPNG.js');
const app = getApp();
//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgData: [],//上传到服务器的图片路径
    uploadUrl: BASEURL + "uploadImage", //上传图片的地址
    addRelpy: BASEURL + "addReplyContent", //提交内容
    isuploaderror: 1, //上传的状态
    src: [],
    imagesData: [],//页面显示的添加图片（本地路径）
    getShareDataUrl: BASEURL + "getShareContent", //获取分享数据的地址

    shareData: {},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.Share();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },


  // 结伴转发
  transpond: function (e) {
    this.onShareAppMessage();
  },

  //分享弹窗
  onShareAppMessage: function (param) {
    var that = this;
    var tit = that.data.shareData.title;
    var imgU = that.data.shareData.imgUrl;

    return {
      title: tit,
      // desc: '',
      path: '',
      imageUrl: imgU,
      success: function (msg) {
        var status = msg.errMsg;

        //分享成功
        var boolean = msg.hasOwnProperty('shareTickets');
        if (status == "shareAppMessage:ok" && boolean) {
          var param = {};
          var userId = wx.getStorageSync("userId"); //用户ID
          var id = "3";
          var random = Math.random();
          // param.sign=md5.h
          var signStr = that.md5Sign(userId, id, random);
          var sign = md5.hexMD5(signStr);
          param.sign = sign;
          param.id = id;
          param.userId = userId;
          param.random = random;

          app.showToast("分享成功");
          app.getHttpData(param, that.data.shareUrl, that.shareCallback);
        } else {
          // app.showToast("分享到群，才能完成任务哦")
        }
      },
      fail: function (msg) {
        console.log(msg)
      }
    }

  },


  //获取后台的分享数据
  Share: function () {
    var that = this;
    wx.request({
      url: that.data.getShareDataUrl,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {

        var title = res.data.title;
        var imgUrl = res.data.imgUrl;

        that.setData({
          shareData: {
            title: title,
            imgUrl: imgUrl
          }
        });
      }
    })
  },

  //分享回调数据更新状态
  shareCallback: function (msg) {

    if (msg.data.status == 1) {
      wx.setStorageSync("userAmount", msg.data.data);
      this.activityListStatus(msg.data.id);
    }
  },

  submitComment: function(e) {

    var param = {};
    param.title = e.detail.value.title.replace(/(^\s*)|(\s*$)/g, "");

    param.content = encodeURIComponent(e.detail.value.con.replace(/(^\s*)|(\s*$)/g, ""));

    if (!param.title) {
      app.showToast("标题不能为空");
      return false;

    }
    if (!param.content) {
      app.showToast("内容不能为空");
      return false;
    }


    var photo = '';
    for (var i = 0; i < this.data.imgData.length; i++) {
      if (this.data.imgData[i]) {
        photo += this.data.imgData[i] + "|";
      }
    }

    param.photo = photo;
    param.userId = wx.getStorageSync("userId");
    
  
    app.getHttpData(param, this.data.addRelpy, this.submitCommentCallback);
  },

  //返回
  goBack: function() {

    wx.switchTab({
      url: '../../pages/community/community',
      fail: function(msg) {
        console.log(msg)
      }
    })
  },

  //提交的回调
  submitCommentCallback: function(msg) {

    if(msg.data.total>1){
      wx.setStorageSync("userAmount", msg.data.total);
    }
    if (msg.data.status == 1) {
      wx.switchTab({
        url: "../../pages/community/community"
      });
    } else {
      app.showToast(msg.data.msg);
    }
  },

  /* 函数描述：作为上传文件时递归上传的函数体体；
   * 参数描述： 
   * filePaths是文件路径数组
   * successUp是成功上传的个数
   * failUp是上传失败的个数
   * i是文件路径数组的指标
   * length是文件路径数组的长度
   */
  uploadDIY(filePaths, successUp, failUp, i, length) {
    var that = this;
    var param = {
      tit: '图片上传中',
      icon: "loading",
      duration: 2000,
      mask: false
    }
    that.uploadImgStatusMsg(param);

    wx.uploadFile({
      url: that.data.uploadUrl,
      filePath: filePaths[i],
      name: 'file',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      formData: {
        'user': 'test'
      },
      success: (res) => {
        var jsonStr = res.data.replace(/\ufeff/g, ""); //转换json
        var objData = JSON.parse(jsonStr);

        successUp++;
        var srcArr = that.data.src;
        srcArr.push(filePaths[i]);

        var imageData = that.data.imgData;
        imageData.push(objData.data);

        that.setData({
          src: srcArr,
          imgData: imageData
        });

      },
      fail: (res) => {
        that.setData({
          isuploaderror: 1
        });
        failUp++;
      },
      complete: () => {
        i++;
        if (i == length) {
          wx.hideToast();

          // 提示框
          var param = {
            tit: successUp + '张上传成功',
            icon: "success",
            duration: 2000,
            mask: false
          };
          that.uploadImgStatusMsg(param);

        } else {
          //递归调用uploadDIY函数
          if (that.data.isuploaderror) {
            //提示框
            var param = {
              tit: '图片上传失败，请重新选择上传',
              icon: "error",
              duration: 2000,
              mask: false
            };
            that.uploadImgStatusMsg(param);

          } else {
            that.uploadDIY(filePaths, successUp, failUp, i, length);
          }
        }
      }
    });
  },

  //选择图片
  uploadImages: function(e) {
    var that = this;
    that.setData({
      isuploaderror: 0
    });

    var nowLen = that.data.imagesData.length;
    var remain = 9 - nowLen;

    wx.chooseImage({
      count: remain,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        var uploadL = res.tempFilePaths.length;
        if ((parseInt(nowLen) + parseInt(uploadL)) > 9) {
        
          //提示框
          var param = {
            tit: '图片最多9张',
            icon: "error",
            duration: 2000,
            mask: false
          };
          that.uploadImgStatusMsg(param);
          return false;
        }

        //追加显示的图片数据
        that.setData({
          imagesData: this.data.imagesData.concat(res.tempFilePaths)  
        });

        var successUp = 0; //成功个数
        var failUp = 0; //失败个数
        var length = res.tempFilePaths.length; //总共个数
        var i = 0; //第几个

        //上传图片到服务器
        that.uploadDIY(res.tempFilePaths, successUp, failUp, i, length);
      },
    });
  },

  //长按上传的图片
  handleLongPress:function(e){
    var that = this;
    var images = that.data.images;
    var index = e.target.dataset.index;//获取当前长按图片下标
    wx.showModal({
      title: '提示',
      content: '确定要删除此图片吗？',
      success: function (res) {
        if (res.confirm) {
          console.log('点击确定了');
          
          var imgsrc = e.target.dataset.src;
          //删除后台已经存好的图片

          var imgData = that.data.imgData;
          imgData.splice(index, 1);

          that.setData({
            imgData: imgData
          });

        } else if (res.cancel) {
          console.log('点击取消了');
          return false;
        }
      }
    })
  },

  //上传图片时候的状态数据
  //duration延长的时间
  //是否显示透明蒙层，防止触摸穿透，默认：false
  //type 类型：loading加载中，base基本
  //icon:success error
  //mask :true false
  uploadImgStatusMsg: function(param) {
    var tit = param.tit;
    var icon = param.icon;
    var duration = param.duration;
    var mask = param.mask;
    wx.showToast({
      title: tit,
      icon: icon,
      duration: duration,
      mask: mask
    })
  },

})