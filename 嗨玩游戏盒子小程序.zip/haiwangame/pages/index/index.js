//获取应用实例
const app = getApp();

//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;
//背景图的基本路径
const BASEBACKGROUNDIMGURL = app.globalData.WXbackgroundImgUrl;
Page({
  data: {
    userInfo: {
      imgUrl: "../resource/images/icon_logo.png",
      userName: "未登录",
      userAmount: "0",
      isstatus: 0, //未登录
    }, //用户信息

    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    particularlyGame: {}, //特别游戏数据
    gamesListData: {}, //除了特别的其他小游戏数据
    bannerData: {}, //banner数据
    indicatorDots: true, //是否显示面板指示点
    autoplay: true, //是否自动
    circular: true, //是否采用链接滑动
    indicatorColor: "#rgba(0, 0, 0, 0.3);", //指示点颜色
    indicatorActiveColor: "#ffffff", // 当前选中的指示点颜色
    YCgamesDataUrl: BASEURL + "index", //远程游戏数据接口

    staticsUrl: BASEURL + "getStatics",
    playGameUserinfoURL: BASEURL + "addHistory", //点击小游戏发送数据到服务器的URL
    sharehidden: "status-hidden", //添加到桌面引导图的是否隐藏
    leadAddToWechidden: "status-hidden", //添加到小程序引导图的是否隐藏
    shareBottom: "360rpx", //分享图标距离顶部的距离
    shareRight: "0", //分享图标距离右边的距离
    screenHeight: 0, //屏幕的高度
    screenWidth: 0, //屏幕的宽度
    littleGamesStyle: "",
    facilityType: "", //设备类型

    getShareDataUrl: BASEURL + "getShareContent", //获取分享数据的地址

    shareData: {},
    backgroundImgUrl: BASEBACKGROUNDIMGURL, //背景图的基本路径

    isRedPacketTem: 0, //是否显示红包模块
    isRedPacket: false, //是否有领取红包

    userHintUrl: BASEURL + "userLoginHint", //提示的URL
    userLoginHint: "", //用户登陆未授权的提示
  },


  /**
   * 隐藏红包模块
   */
  hideRedPacket: function(msg) {
    var that = this;
    console.log(999666);
    console.log(msg);
    if (msg.data.isFirst == 0) {
      wx.showToast({
        title: "红包已经领取过了哦！",
        icon: 'none',
        duration: 2000
      })
    }else{
      wx.showToast({
        title: "恭喜您在首次登录时获得200新人金币红包！",
        icon: 'none',
        duration: 2000
      })
    }

    wx.setStorageSync('openId', msg.data.openId); //保存openId
    wx.setStorageSync('userImg', msg.data.avatarUrl); //保存用户头像
    wx.setStorageSync('userName', decodeURIComponent(msg.data.nickName.substring(0, 10))); //保存用户昵称
    wx.setStorageSync('userAmount', msg.data.amount); //保存用户金币
    wx.setStorageSync('userId', msg.data.userId); //保存用户userId

    that.editUserinfo(); //修改用户的数据

    //修改红包模块的状态
    that.setData({
      isRedPacket: true,
    });
  },

  isHideRedPacket:function(){
    console.log(12);
    //修改红包模块的状态
    this.setData({
      isRedPacketTem: 0,
    });
  },
  /**
   * 修改红包的显示状态
   */
  editRedPacketStatus: function() {
    var userId = wx.getStorageSync('userId');
    if (userId) {
      this.setData({
        isRedPacketTem: 0
      });
    }else{
      this.setData({
        isRedPacketTem: 1
      });
    } 
    console.log("红包的状态");
    console.log(this.data.isRedPacketTem);
  },

  /**
   * 路径跳转
   */
  navSkip: function(e) {
    this.setData({
      isRedPacketTem: 0
    });

    wx.setStorageSync("shopType", 3)
    var u = e.currentTarget.dataset.url;
    wx.switchTab({
      url: u, //注意switchTab只能跳转到带有tab的页面，不能跳转到不带tab的页面
    })
  },

  //获取设备类型和修改默认类型
  editFacilityType: function() {
    var that = this;
    var t = '';
    wx.getSystemInfo({
      success: function(res) {

        if (res.platform == "devtools") {
          t = 'PC';
        } else if (res.platform == "ios") {
          t = 'IOS';
        } else if (res.platform == "android") {
          t = 'android';
        }
        //修改
        that.setData({
          facilityType: t,
        });
      }
    })
  },

  onLoad: function(options) {
    var param = {
      "type": 1
    }
    app.getHttpData(param, this.data.userHintUrl, this.editUserLoginHint);
    var clientId = '';
    var that = this;
    var code = '';
    var openId = wx.getStorageSync("openId");
    that.Share();
    if (options.hasOwnProperty("clientId")) {
      clientId = options.clientId; //渠道ID
      wx.login({
        success: function(res) {
          code = res.code;
          var param = {};
          param.code = code;
          param.clientId = clientId;
          param.openId = openId;
          app.getHttpData(param, that.data.staticsUrl, that.staticsCallback);
        },
      })
    } else {
      //自然量

      if (!openId) {
        wx.login({
          success: function(res) {
            code = res.code;
            var param = {};
            param.code = code;
            param.clientId = clientId;
            param.openId = openId;
            app.getHttpData(param, that.data.staticsUrl, that.staticsCallback);
          },
        })
      }
    }

    var that = this;
    that.longRangeData();
    // that.editUserinfo(); //登录获取用户数据
    that.editScreenHW(); //修改屏幕的高，宽


    wx.showShareMenu({
      // shareTicket 是获取转发目标群信息的票据，只有拥有 shareTicket 才能拿到群信息，用户每次转发都会生成对应唯一的shareTicket 。
      withShareTicket: true
    });


    var userImg1 = wx.getStorageSync('userImg'); //获取用户头像
    var userName1 = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount1 = wx.getStorageSync('userAmount'); //获取用户金币
    var tmp = {};
    if (userImg1) {
      tmp.userImg = userImg1;
    } else {
      tmp.userImg = "../resource/images/icon_logo.png"
    }

    if (userName1) {
      tmp.userName = userName1;
    } else {
      tmp.userName = "未登录";
    }

    if (userAmount1) {
      tmp.userAmount = userAmount1;
    } else {
      tmp.userAmount = 0;
    }

    this.setData({
      userData: tmp,
    })


    var param = {};
    param.userId = wx.getStorageSync("userId");

    app.getHttpData('', this.data.getShareDataUrl, this.getShareContentCallback);

    this.editFacilityType();

  },

  getShareContentCallback(msg) {

    this.setData({
      shareData: msg.data,
    })
  },

  staticsCallback: function(msg) {
    console.log(msg);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

    var that = this;

    that.longRangeData();
    that.editUserinfo(); //登录获取用户数据
    that.editScreenHW(); //修改屏幕的高，宽
    that.editFacilityType(); //获取设备类型
    that.editRedPacketStatus();
  },

  //修改屏幕的宽，高度
  editScreenHW: function() {
    var that = this;
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          screenHeight: res.windowHeight,
          screenWidth: res.windowWidth,
        });
      }
    });
  },

  //拖拽分享图标
  ballMoveEvent: function(e) {
    var pageX = e.touches[0].pageX;
    var pageY = e.touches[0].pageY;

    if (pageX <= 50) return;
    if (pageX > this.data.screenWidth - 30) return;
    if (this.data.screenHeight - pageY <= 0) return;
    if (pageY <= 118) return;

    //这里用right和bottom.所以需要将pageX pageY转换
    var x = this.data.screenWidth - pageX - 30;
    var y = this.data.screenHeight - pageY - 30;

    this.setData({
      shareBottom: y + "px",
      shareRight: x + "px",
    });
  },
  ballEndEvent: function() {
    this.setData({
      littleGamesStyle: ""
    });
  },
  ballStartEvent: function() {
    this.setData({
      littleGamesStyle: "height:800rpx;overflow:hidden;"
    });
  },

  //获取远程数据
  longRangeData: function() {
    var that = this;
    wx.request({
      url: that.data.YCgamesDataUrl,
      data: {},
      method: 'POST',
      header: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        var topSwiper = app.twoArrFormat(res.data.topSwiper);
        var data = app.thirdArrFormat(res.data.data);
        var middle = app.twoArrFormat(res.data.middleSwiper);


        console.log(99999);
        console.log(topSwiper);
        console.log(data);

        that.particularlyGame(topSwiper); //特别推荐
        that.gamesListData(data); //其他游戏数据
        that.bannerListData(middle); //banner


      },
      fail: function(res) {
        console.log('submit fail');
      }
    });
  },

  //修改banner数据
  bannerListData: function(data) {
    this.setData({
      bannerData: data
    });
  },

  //修改除了特别的其他小游戏数据
  gamesListData: function(data) {
    this.setData({
      gamesListData: data
    });
  },

  //修改特别推荐游戏数据
  particularlyGame: function(data) {

    this.setData({
      particularlyGame: data
    });
  },

  //修改用户的数据
  editUserinfo: function() {
    var userImg = wx.getStorageSync('userImg'); //获取用户头像
    var userName = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount = wx.getStorageSync('userAmount'); //获取用户金币
    var userId = wx.getStorageSync("userId");


    if (userId) {
      this.setData({
        userInfo: {
          imgUrl: userImg,
          userName: userName,
          userAmount: userAmount,
          isstatus: 1,
        }
      });
    }
  },

  //回到顶部
  goTop: function(e) { // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },

  // 结伴转发
  transpond: function(e) {
    this.onShareAppMessage();
  },

  //分享弹窗
  onShareAppMessage: function(param) {
    var that = this;
    var tit = that.data.shareData.title;
    var imgU = that.data.shareData.imgUrl;
    return {
      title: tit,
      // desc: '',
      path: '',
      imageUrl: imgU,
      success: function(msg) {
        var status = msg.errMsg;
        //分享成功
        var boolean = msg.hasOwnProperty('shareTickets');
        if (status == "shareAppMessage:ok" && boolean) {
          var param = {};
          var userId = wx.getStorageSync("userId"); //用户ID
          var id = "3";
          var random = Math.random();
          // param.sign=md5.h
          var signStr = that.md5Sign(userId, id, random);
          var sign = md5.hexMD5(signStr);
          param.sign = sign;
          param.id = id;
          param.userId = userId;
          param.random = random;
          app.showToast("分享成功");
          app.getHttpData(param, that.data.shareUrl, that.shareCallback);
        } else {
          // app.showToast("分享到群，才能完成任务哦")
        }
      },
      fail: function(msg) {
        console.log(msg)
      }
    }

  },


  //获取后台的分享数据
  Share: function() {
    var that = this;
    wx.request({
      url: that.data.getShareDataUrl,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function(res) {

        var title = res.data.title;
        var imgUrl = res.data.imgUrl;

        that.setData({
          shareData: {
            title: title,
            imgUrl: imgUrl
          }
        });
      }
    })
  },


  //点击授权获取用户信息
  onGotUserInfo: function(e) {
    var t = e.currentTarget.dataset.type;
    var that = this;
    //获取提示数据
    console.log("你好");
    console.log(e);
    
    if (e.detail.errMsg == "getUserInfo:fail auth deny") {
  
      if (t == "red") {
        app.showToast("需要点击授权才可以获得金币红包哦~");
      }else{
        app.showToast("需要点击授权之后才可以体验游戏~");
      }
      console.log(123);
      return false;
    }

    app.getUserRedPackage(e, this.hideRedPacket);
  },

  /**
   * 设置用户登陆未授权的提示
   */
  editUserLoginHint: function(res) {
    console.log(res.data.msg);
    this.setData({
      userLoginHint: res.data.msg
    });
  },



  //点击显示添加到桌面的引导图
  showLeadShareImg: function() {
    this.setData({
      sharehidden: "",
      userInfo: {
        isstatus: 1
      }
    });
  },

  //点击隐藏添加到桌面的引导图
  hiddenLeadShareImg: function() {
    this.setData({
      sharehidden: "status-hidden",
      userInfo: {
        isstatus: 0
      }
    });
  },
  //点击显示添加到小程序的引导图
  showleadAddToWechImg: function() {
    this.setData({
      leadAddToWechidden: "",
      userInfo:{
        isstatus:1
      }
    });
  },

  //点击隐藏添加到小程序引导图
  hiddenleadAddToWechImg: function() {
    this.setData({
      leadAddToWechidden: "status-hidden",
      userInfo: {
        isstatus: 0
      }
    });
  },



  //点击小游戏icon跳转是发送后台的数据
  playGameUserinfo: function(da) {
    console.log(123);
    // var id = da.currentTarget.dataset.id;
    var id = '';
    if (da.currentTarget.dataset.hasOwnProperty("id")) {
      id = da.currentTarget.dataset.id;
      console.log(id + "ddddd")
    }
    var gameId = da.currentTarget.dataset.gameid;
    var userId = wx.getStorageSync('userId'); //获取用户userID;

    if (gameId && userId) {
      var that = this;
      wx.request({
        url: that.data.playGameUserinfoURL,
        data: {
          'userId': userId,
          'gameId': gameId,
          'posId': id,
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function(res) {
          if (res.data.total >= 1) {

            wx.setStorageSync("userAmount", res.data.total);
            that.editUserinfo();
          }
          console.log(res);
        },
        fail: function(res) {
          console.log('submit fail');
        }
      });
    }
  }
});