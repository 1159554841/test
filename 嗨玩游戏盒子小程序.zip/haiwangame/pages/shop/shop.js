const app = getApp();
const md5 = require("../../utils/md5.js");
//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isSignIn: "1", //是否签到
    isShow1: "show-cont", //兑换商城显示
    isShow2: "", //任务中心显示
    isShow3: "", //积分记录显示
    isShow4: "", //兑换规则显示
    isActive1: "active", //兑换商城active
    isActive2: "", //任务中心active
    isActive3: "", //积分记录active
    isActive4: "", //兑换规则active
    isRecordShow1: "active", //获取记录
    isRecordShow2: "", //兑换记录记录
    convertibilityData: "还没有重后台获取数据", //兑换规则数据
    convertibilityDataURL: "", //兑换规则URL

    userIsLogin: false,

    shopIndexUrl: BASEURL + "getShopList", //获取商城首页数据
    shopExchangeUrl: BASEURL + "shopExchange", //商店兑换页面地址
    customEchangeList: BASEURL + "customEchangeList", //个人兑换记录
    getPointByActivity: BASEURL + "getPointByActivity", //获取记录，通过活动获得
    getActivityUrl: BASEURL + "getActivityCenter",
    getSignUrl: BASEURL + "getSignData", //签名的url
    getSignStatus: BASEURL + "getMemberSign", //签到的状态
    shareUrl: BASEURL + "getShare", //分享的地址
    getShareDataUrl: BASEURL + "getShareContent", //获取分享数据的地址
    activityClickCUrl: BASEURL + "activityClickC", //点击为完成任务次数的地址

    shareData: {},

    getActivityData: {}, //任务中心的数据
    shopData: {},
    echangeDataList: {}, //积分兑换记录
    exchangeActivityList: {}, //积分获取记录

    userData: {
      userImg: "../resource/images/icon_logo.png",
      userName: "未登录",
      userAmount: 0,
    },

    leadAddToWechidden: "status-hidden", //添加到小程序引导图的是否隐藏
    sharehidden: "status-hidden", //添加到桌面引导图的是否隐藏
    attentionhidden: "status-hidden", //关注我们引导图的是否隐藏
    facilityType: "", //设备类型
    isShowAndroid: "android_9",
    isShowIos: "IOS_10",
    isDailyAttendance: 0, //每日签到
    isDailyShare: 0, //每日分享

    userHintUrl: BASEURL + "userLoginHint", //提示的URL
    userLoginHint: "", //用户登陆未授权的提示
  },


  //获取设备类型和修改默认类型
  editFacilityType: function() {
    var that = this;
    var t = '';
    wx.getSystemInfo({
      success: function(res) {

        if (res.platform == "devtools") {
          t = 'PC';
        } else if (res.platform == "ios") {
          t = 'IOS';
        } else if (res.platform == "android") {
          t = 'android';
        }
        //修改
        that.setData({
          facilityType: t,
        });
      }
    })
  },


  //点击显示添加到小程序的引导图
  showleadAddToWechImg: function() {
    this.setData({
      leadAddToWechidden: ""
    });
  },

  //点击隐藏添加到小程序的引导图
  hiddenleadAddToWechImg: function() {
    this.setData({
      leadAddToWechidden: "status-hidden"
    });
  },

  //点击显示添加到桌面的引导图
  showLeadShareImg: function() {
    this.setData({
      sharehidden: ""
    });
  },

  //点击隐藏添加到桌面的引导图
  hiddenLeadShareImg: function() {
    this.setData({
      sharehidden: "status-hidden"
    });
  },

  //点击显示关注我们的引导图
  showAttentionImg: function() {
    this.setData({
      attentionhidden: ""
    });
  },

  //点击隐藏关注我们的引导图
  hiddenAttentionImg: function() {
    this.setData({
      attentionhidden: "status-hidden"
    });
  },



  //签到状态改变
  getSignStatusCallback: function(msg) {
    var money = msg.data.money;
    var isFinsh = msg.data.isFinsh;
    if (isFinsh == 1) {
      this.setData({
        isSignIn: 0,
        isDailyAttendance: 1
      });
    }

    wx.setStorageSync("userAmount", money);

  },

  getShareContentCallback(msg) {

    this.setData({
      shareData: msg.data,
    })
  },

  //获取任务中心的数据回调
  getActivityDataList: function(msg) {
    this.setData({
      getActivityData: msg.data,
    });
  },

  //任务中心数据状态处理
  activityListStatus: function(id) {

    var tmp = this.data.getActivityData;
    for (var i = 0; i < tmp.length; i++) {
      if (tmp[i].id == id) {
        tmp[i].isFinsh = 1;
      }
    }
    this.setData({
      getActivityData: tmp,
    })
  },

  //积分兑换记录
  getCustomEchangeList: function(msg) {
    this.setData({
      echangeDataList: msg.data,
    });
  },

  //积分获取记录
  getExchangeActivity: function(msg) {
    this.setData({
      exchangeActivityList: msg.data,
    })
  },
  //修改用户的登录状态
  editUserinfo: function() {
    var userAmount = wx.getStorageSync('userAmount'); //获取用户金币
    var userId = wx.getStorageSync('userId'); //获取用户金币
    var userImg = wx.getStorageSync('userImg'); //获取用户头像
    var userName = wx.getStorageSync('userName'); //获取用户昵称
    
    console.log("userId===" + userId);
    console.log("userName===" + userName);
    console.log("userAmount===" + userAmount);
    console.log("userImg===" + userImg);
    
    if (userId>=1) {
      this.setData({
        userData: {
          userImg: userImg,
          userName: userName,
          userAmount: userAmount
        },
        userIsLogin: true,
      });
    }
  },
  md5Sign: function(userId, shopId, random) {
    var key = "higame$$#@&u";

    return userId + shopId + random + key;
  },

  // 结伴转发
  transpond: function(e) {
    this.onShareAppMessage();
  },


  //分享弹窗
  onShareAppMessage: function(param) {

    if (typeof(param.target) != 'undefined'){
      var shareT = param.target.dataset.type;
    }

    var title = this.data.shareData.title;
    var imgUrl = this.data.shareData.imgUrl;
    var that = this;

    return {
      title: title,
      // desc: '',
      path: 'pages/index/index',
      imageUrl: imgUrl,
      success: function(msg) {
        var status = msg.errMsg;
        //分享成功
        var boolean = msg.hasOwnProperty('shareTickets');
        if (status == "shareAppMessage:ok" && boolean) {
          var param = {};
          var userId = wx.getStorageSync("userId"); //用户ID
          var id = "3";
          var random = Math.random();
          // param.sign=md5.h
          var signStr = that.md5Sign(userId, id, random);
          var sign = md5.hexMD5(signStr);
          param.sign = sign;
          param.id = id;
          param.userId = userId;
          param.random = random;
          app.showToast("分享成功");
          // 修改每日分享的状态
          that.setData({
            isDailyShare: 1
          });
          app.getHttpData(param, that.data.shareUrl, that.shareCallback);
        } else {
       
          if (shareT)
          {
            app.showToast("分享到群，才能完成任务哦")
          }
        }
      },
      fail: function(msg) {
        console.log(msg)
      }
    }
  },

  //分享回调数据更新状态
  shareCallback: function(msg) {
    if (msg.data.status == 1) {
      wx.setStorageSync("userAmount", msg.data.data);
      var photo = wx.getStorageSync("userImg");
      var userName = wx.getStorageSync("userName")
      this.setData({
        userData: {
          userAmount: msg.data.data,
          userImg: photo,
          userName: userName,

        }
      });
      this.activityListStatus(msg.data.id);
    }
  },

  //去首页
  goIndex: function() {
    wx.switchTab({
      url: '../../pages/index/index',
    })
  },

  //去社区页面
  goComment: function() {
    wx.switchTab({
      url: '../../pages/community/community',
    })
  },

  //立即兑换
  goToChange: function(e) {
    var random = Math.random(1); //随机数
    var userId = wx.getStorageSync("userId"); //用户ID
    var id = e.currentTarget.dataset.id;

    if (!userId) {
      app.showToast("请先登录");
      return false;
    }

    var signStr = this.md5Sign(userId, id, random);
    var sign = md5.hexMD5(signStr);

    var param = {};
    param.userId = userId;
    param.id = id;
    param.random = random;
    param.sign = sign;

    app.getHttpData(param, this.data.shopExchangeUrl, this.changeCallback)
  },

  //兑换回调状态
  changeCallback: function(msg) {
    if (msg.data.status == 1) {

      var amount = msg.data.data; //剩下的金额

      var tmp = this.data.userData;
      tmp.userAmount = amount;
      this.setData({
        userData: tmp,
      });

      wx.setStorageSync("userAmount", amount);
      app.showToast("兑换成功");
    } else {
      app.showToast(msg.data.msg);
    }
  },

  //获取商店的数据
  getShopDataList: function(msg) {

    this.setData({
      shopData: msg.data,
    });
  },

  /**
 * 设置用户登陆未授权的提示
 */
  editUserLoginHint: function (res) {
    console.log(res.data.msg);
    this.setData({
      userLoginHint: res.data.msg
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    
    var param = {
      "type": 1
    }
    app.getHttpData(param, this.data.userHintUrl, this.editUserLoginHint);


    this.clickSwitchoverContent(1,"1");
    
    wx.showShareMenu({
      // shareTicket 是获取转发目标群信息的票据，只有拥有 shareTicket 才能拿到群信息，用户每次转发都会生成对应唯一的shareTicket 。
      withShareTicket: true
    });

    app.getHttpData('', this.data.shopIndexUrl, this.getShopDataList); //商店的数据
    var param = {};
    param.userId = wx.getStorageSync("userId");
    app.getHttpData(param, this.data.customEchangeList, this.getCustomEchangeList); //积分兑换的数据

    //获取通过活动获取数据
    app.getHttpData(param, this.data.getPointByActivity, this.getExchangeActivity);


    var userImg1 = wx.getStorageSync('userImg'); //获取用户头像
    var userName1 = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount1 = wx.getStorageSync('userAmount'); //获取用户金币
    var tmp = {};
    if (userImg1) {
      tmp.userImg = userImg1;
    } else {
      tmp.userImg = "../resource/images/icon_logo.png"
    }

    if (userName1) {
      tmp.userName = userName1;
    } else {
      tmp.userName = "未登录";
    }

    if (userAmount1) {
      tmp.userAmount = userAmount1;
    } else {
      tmp.userAmount = 0;
    }

    this.setData({
      userData: tmp,
    })


    app.getHttpData('', this.data.getShareDataUrl, this.getShareContentCallback);

    this.editFacilityType();
  },

  //每日签到
  getSign: function(e) {
    var id = e.currentTarget.dataset.id;
    var status = e.currentTarget.dataset.status;
    var userId = wx.getStorageSync("userId");

    var random = Math.random;
    var signStr = this.md5Sign(userId, id, random);
    var sign = md5.hexMD5(signStr);

    var param = {};
    param.id = id;
    param.userId = userId;
    param.random = random;
    param.sign = sign;

    if (status == 0) {
      this.setData({
        isDailyAttendance: 1
      });
    }

    app.getHttpData(param, this.data.getSignUrl, this.getSignCallback)

  },

  //签到回调数据
  getSignCallback: function(msg) {
    if (msg.data.status == 1) {

      var tmp = this.data.userData;
      tmp.userAmount = msg.data.data;
      this.setData({
        userData: tmp,
        isSignIn: 0,
        isDailyAttendance: 1
      });
      wx.setStorageSync("userAmount", msg.data.data);
    } else {
      app.showToast(msg.data.msg);
    }
  },

  //获取兑换规则数据
  getconvertibilityData: function() {
    var that = this;
    wx.request({
      url: that.data.convertibilityDataURL,
      data: {},
      method: 'POST',
      header: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        console.log(res);
      },
      fail: function(res) {
        console.log('submit fail');
      }
    });
  },

  // 点击切换内容
  clickSwitchoverContent: function(i,o) {
   
    var index = o ? o : i.currentTarget.dataset.i;

    var data = {};
    var param = {};
    param.userId = wx.getStorageSync("userId");

    console.log(12);
    console.log(index);


    switch (index) {
      case "1":
        data = {
          isShow1: "show-cont", //兑换商城显示
          isShow2: "", //任务中心显示
          isShow3: "", //积分记录显示
          isShow4: "", //兑换规则显示

          isActive1: "active", //兑换商城active
          isActive2: "", //任务中心active
          isActive3: "", //积分记录active
          isActive4: "", //兑换规则active
        };;
        app.getHttpData('', this.data.shopIndexUrl, this.getShopDataList); //商店的数据
        break;
      case "2":
        data = {
          isShow1: "", //兑换商城显示
          isShow2: "show-cont", //任务中心显示
          isShow3: "", //积分记录显示
          isShow4: "", //兑换规则显示

          isActive1: "", //兑换商城active
          isActive2: "active", //任务中心active
          isActive3: "", //积分记录active
          isActive4: "", //兑换规则active
        };;
        //任务中心的数据
        param.version = app.globalData.Version;

        app.getHttpData(param, this.data.getActivityUrl, this.getActivityDataList);
        break;
      case "3":
        data = {
          isShow1: "", //兑换商城显示
          isShow2: "", //任务中心显示
          isShow3: "show-cont", //积分记录显示
          isShow4: "", //兑换规则显示

          isActive1: "", //兑换商城active
          isActive2: "", //任务中心active
          isActive3: "active", //积分记录active
          isActive4: "", //兑换规则active
        };;
        app.getHttpData(param, this.data.getPointByActivity, this.getExchangeActivity);
        break;
      case "4":
        data = {
          isShow1: "", //兑换商城显示
          isShow2: "", //任务中心显示
          isShow3: "", //积分记录显示
          isShow4: "show-cont", //兑换规则显示

          isActive1: "", //兑换商城active
          isActive2: "", //任务中心active
          isActive3: "", //积分记录active
          isActive4: "active", //兑换规则active
        };;
        break;
      default:
        console.log(index);
    };

    this.setData(data);
  },

  // 点击切换记录数据
  clickSwitchoverRecordData: function(i) {


    var param = {};
    param.userId = wx.getStorageSync("userId");
    var index = i.currentTarget.dataset.i;
    var data = {};
    if (index == "1") {
      data = {
        isRecordShow1: "active", //获取记录
        isRecordShow2: "", //兑换记录记录
      }
      //获取通过活动获取数据
      app.getHttpData(param, this.data.getPointByActivity, this.getExchangeActivity);

    }

    if (index == "2") {
      data = {
        isRecordShow1: "", //获取记录
        isRecordShow2: "active", //兑换记录记录
      }


      app.getHttpData(param, this.data.customEchangeList, this.getCustomEchangeList); //积分兑换的数据


    }
    this.setData(data);

  },
  onGotUserInfo: function(e) {
    var that = this;
    //获取提示数据

    if (e.detail.errMsg == "getUserInfo:fail auth deny") {
      app.showToast("需要点击授权才可以开始任务~");
      return false;
    }


    if (e && e.detail.userInfo)
    {
      app.sendUserinfoData(e, this);
    }
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.editUserinfo();
    var param = {};
    param.userId = wx.getStorageSync("userId");
    param.version = app.globalData.Version;
    app.getHttpData(param, this.data.getSignStatus, this.getSignStatusCallback);
    app.getHttpData(param, this.data.getActivityUrl, this.getActivityDataList);
  },

  //任务点击次数
  activityClickC: function(e) {
    var id = e.currentTarget.dataset.activityid;
    var userId = wx.getStorageSync('userId'); //获取用户userID;

    if (id && userId) {
      var that = this;
      wx.request({
        url: that.data.activityClickCUrl,
        data: {
          'userId': userId,
          'activityId': id,
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function(res) {
          console.log(res);
        },
        fail: function(res) {
          console.log('submit fail');
        }
      });
    }
  }

})