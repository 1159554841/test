//获取应用实例
const app = getApp();
//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {
      imgUrl: "../resource/images/icon_logo.png",
      userName: "未登录",
      userAmount: 0
    }, //用户信息

    recentlyPlayData: '', //最近在玩的游戏数据
    userinfoBaseDataUrl: BASEURL + "memberCenter", // 获取用户的基本数据URL

    leadAddToWechidden: "status-hidden", //添加到小程序引导图的是否隐藏
    sharehidden: "status-hidden", //添加到桌面引导图的是否隐藏
    attentionhidden: "status-hidden", //关注我们引导图的是否隐藏
    facilityType: "",//设备类型
    getShareDataUrl: BASEURL + "getShareContent", //获取分享数据的地址

    shareData: {},
    userHintUrl: BASEURL + "userLoginHint", //提示的URL
    userLoginHint: "", //用户登陆未授权的提示
  },


  /**
* 设置用户登陆未授权的提示
*/
  editUserLoginHint: function (res) {
    console.log(res.data.msg);
    this.setData({
      userLoginHint: res.data.msg
    });
  },



  //获取设备类型和修改默认类型
  editFacilityType: function () {
    var that = this;
    var t = '';
    wx.getSystemInfo({
      success: function (res) {

        if (res.platform == "devtools") {
          t = 'PC';
        } else if (res.platform == "ios") {
          t = 'IOS';
        } else if (res.platform == "android") {
          t = 'android';
        }
        //修改
        that.setData({
          facilityType: t,
        });
      }
    })
  },


  //点击显示添加到小程序的引导图
  showleadAddToWechImg: function() {
    this.setData({
      leadAddToWechidden: ""
    });
  },


  myShop:function(){

    wx.switchTab({
      url: '../../pages/shop/shop',
    })
  },
  //点击隐藏添加到小程序的引导图
  hiddenleadAddToWechImg: function() {
    this.setData({
      leadAddToWechidden: "status-hidden"
    });
  },

  //点击显示添加到桌面的引导图
  showLeadShareImg: function() {
    this.setData({
      sharehidden: ""
    });
  },

  //点击隐藏添加到桌面的引导图
  hiddenLeadShareImg: function() {
    this.setData({
      sharehidden: "status-hidden"
    });
  },

  //点击显示关注我们的引导图
  showAttentionImg: function() {
    this.setData({
      attentionhidden: ""
    });
  },

  //点击隐藏关注我们的引导图
  hiddenAttentionImg: function() {
    this.setData({
      attentionhidden: "status-hidden"
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var param = {
      "type": 1
    }
    app.getHttpData(param, this.data.userHintUrl, this.editUserLoginHint);



    var that = this;
    that.Share();
    
    that.editUserinfo(); //修改用户数据
    that.editFacilityType();
  },

  // 结伴转发
  transpond: function (e) {
    this.onShareAppMessage();
  },

  //分享弹窗
  onShareAppMessage: function (param) {
    var that = this;
    var tit = that.data.shareData.title;
    var imgU = that.data.shareData.imgUrl;
    return {
      title: tit,
      // desc: '',
      path: '',
      imageUrl: imgU,
      success: function (msg) {
        var status = msg.errMsg;
        //分享成功
        var boolean = msg.hasOwnProperty('shareTickets');
        if (status == "shareAppMessage:ok" && boolean) {
          var param = {};
          var userId = wx.getStorageSync("userId"); //用户ID
          var id = "3";
          var random = Math.random();
          // param.sign=md5.h
          var signStr = that.md5Sign(userId, id, random);
          var sign = md5.hexMD5(signStr);
          param.sign = sign;
          param.id = id;
          param.userId = userId;
          param.random = random;
          app.showToast("分享成功");
          app.getHttpData(param, that.data.shareUrl, that.shareCallback);
        } else {
          // app.showToast("分享到群，才能完成任务哦")
        }
      },
      fail: function (msg) {
        console.log(msg)
      }
    }

  },


  //获取后台的分享数据
  Share: function () {
    var that = this;
    wx.request({
      url: that.data.getShareDataUrl,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {

        var title = res.data.title;
        var imgUrl = res.data.imgUrl;

        that.setData({
          shareData: {
            title: title,
            imgUrl: imgUrl
          }
        });
      }
    })
  },
  //分享回调数据更新状态
  shareCallback: function (msg) {
    if (msg.data.status == 1) {
      wx.setStorageSync("userAmount", msg.data.data);
      this.activityListStatus(msg.data.id);
    }
  },



  /**
  * 生命周期函数--监听页面显示
  */
  onShow: function () {
    var that = this;
    // that.longRangeData();
    that.editUserinfo(); //登录获取用户数据
    // that.editScreenHW(); //修改屏幕的高，宽
    that.recentlyPlayData(); // 最近在玩的游戏数据
  },

  // 最近在玩的游戏数据
  recentlyPlayData: function() {

    var data = {};
    var that = this;
    var userId = wx.getStorageSync('userId'); //获取用户userId

    wx.request({
      url: that.data.userinfoBaseDataUrl,
      data: {
        userId: userId
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function(res) {
        if (res.data.data.gameData) {

          var tmp = res.data.data.gameData;
          var gameData = app.twoArrFormat(tmp);
          that.setData({
            recentlyPlayData: gameData
          });
        }
      }
    })
  },


  //修改用户的数据
  editUserinfo: function() {
    var userImg = wx.getStorageSync('userImg'); //获取用户头像
    var userName = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount = wx.getStorageSync('userAmount'); //获取用户金币
    var userId = wx.getStorageSync("userId");
    console.log("个人中心userID=="+userId);
    if (userId) {
      this.setData({
        userInfo: {
          imgUrl: userImg,
          userName: userName,
          userAmount: userAmount,
        }
      });
    }
    this.recentlyPlayData(); // 最近在玩的游戏数据
  },
  //点击授权获取用户信息
  onGotUserInfo: function(e) {
    var that = this;
    //获取提示数据

    if (e.detail.errMsg == "getUserInfo:fail auth deny") {
      app.showToast("需要点击授权才可以查看个人信息~");

      return false;
    }
    
    if (e && e.detail.userInfo) {
      app.sendUserinfoData(e, this);
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },


  //跳转页面
  navigateTo: function(e) {
    var url = e.currentTarget.dataset.url;
   
    wx.switchTab({
      url: "../index/index",
      fail: function (res) {
        console.log(res)
      }
    });
  }

});