// pages/community/community.js
const app = getApp();
//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;
//背景图的基本路径
const BASEBACKGROUNDIMGURL = app.globalData.WXbackgroundImgUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userIsLogin: false,
    communitList: BASEURL + "getCommunityList", //文章列表
    commentList: BASEURL + "getRelpyList", //评论列表
    contentDetail: BASEURL + "getContentById", //文章列表的详细内容
    commentDetail: BASEURL + "getReplyById", //评论的详情页面
    commentListData: {}, //评论数据列表
    addLike: BASEURL + "addLike", //添加点赞
    images: {},
    getShareDataUrl: BASEURL + "getShareContent", //获取分享数据的地址
    backgroundImgUrl: BASEBACKGROUNDIMGURL, //背景图的基本路径
    shareData: {},
    userHintUrl: BASEURL + "userLoginHint", //提示的URL
    userLoginHint: "", //用户登陆未授权的提示
  },

  /**
* 设置用户登陆未授权的提示
*/
  editUserLoginHint: function (res) {
    console.log(res.data.msg);
    this.setData({
      userLoginHint: res.data.msg
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var param = {
      "type": 1
    }
    app.getHttpData(param, this.data.userHintUrl, this.editUserLoginHint);

    var that = this;
    that.Share();
    that.editUserinfo();
    // that.
    wx.showShareMenu({
      // shareTicket 是获取转发目标群信息的票据，只有拥有 shareTicket 才能拿到群信息，用户每次转发都会生成对应唯一的shareTicket 。
      withShareTicket: true
    });

    var userImg1 = wx.getStorageSync('userImg'); //获取用户头像
    var userName1 = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount1 = wx.getStorageSync('userAmount'); //获取用户金币
    var tmp = {};
    if (userImg1) {
      tmp.userImg = userImg1;
    } else {
      tmp.userImg = "../resource/images/icon_logo.png"
    }

    if (userName1) {
      tmp.userName = userName1;
    } else {
      tmp.userName = "未登录";
    }

    if (userAmount1) {
      tmp.userAmount = userAmount1;
    } else {
      tmp.userAmount = 0;
    }

    this.setData({
      userData: tmp,
    })

    app.getHttpData('', this.data.getShareDataUrl, this.getShareContentCallback);

  },

  getShareContentCallback(msg) {

    this.setData({
      shareData: msg.data,
    })
  },


  // 结伴转发
  transpond: function(e) {
    this.onShareAppMessage();
  },

  //分享弹窗
  onShareAppMessage: function(param) {
    var that = this;
    var tit = that.data.shareData.title;
    var imgU = that.data.shareData.imgUrl;

    return {
      title: tit,
      // desc: '',
      path: '',
      imageUrl: imgU,
      success: function(msg) {
        var status = msg.errMsg;

        //分享成功
        var boolean = msg.hasOwnProperty('shareTickets');
        if (status == "shareAppMessage:ok" && boolean) {
          var param = {};
          var userId = wx.getStorageSync("userId"); //用户ID
          var id = "3";
          var random = Math.random();
          // param.sign=md5.h
          var signStr = that.md5Sign(userId, id, random);
          var sign = md5.hexMD5(signStr);
          param.sign = sign;
          param.id = id;
          param.userId = userId;
          param.random = random;
  
          app.showToast("分享成功");
          app.getHttpData(param, that.data.shareUrl, that.shareCallback);
        } else {
          // app.showToast("分享到群，才能完成任务哦")
        }
      },
      fail: function(msg) {
        console.log(msg)
      }
    }

  },


  //获取后台的分享数据
  Share: function() {
    var that = this;
    wx.request({
      url: that.data.getShareDataUrl,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function(res) {

        var title = res.data.title;
        var imgUrl = res.data.imgUrl;

        that.setData({
          shareData: {
            title: title,
            imgUrl: imgUrl
          }
        });
      }
    })
  },
  //分享回调数据更新状态
  shareCallback: function(msg) {

    if (msg.data.status == 1) {
      wx.setStorageSync("userAmount", msg.data.data);
      this.activityListStatus(msg.data.id);
    }
  },




  imageLoad: function(e) {
    var $width = e.detail.width, //获取图片真实宽度
      $height = e.detail.height,
      ratio = $width / $height; //图片的真实宽高比例

    var viewWidth = 718, //设置图片显示宽度，左右留有16rpx边距
      viewHeight = 718 / ratio; //计算的高度值
    var image = this.data.images;
    //将图片的datadata-index作为image对象的key,然后存储图片的宽高值

    image[e.target.dataset.index] = {
      width: viewWidth,
      height: viewHeight
    };

    this.setData({
      images: image
    })
  },



  //修改用户的登录状态
  editUserinfo: function() {
    var userImg = wx.getStorageSync('userImg'); //获取用户头像
    var userName = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount = wx.getStorageSync('userAmount'); //获取用户金币

    if (userName) {
      this.setData({
        userIsLogin: true
      });
    }
  },


  //获取公告数据
  getCommunityList: function(msg) {
    this.setData({
      community: msg.data.data,
    });

   
  },


  //获取文章评论的数据
  getCommentList: function(msg) {
   

    for (var i = 0; i < msg.data.length; i++) {
      msg.data[i].tipContent = decodeURIComponent(msg.data[i].tipContent).substring(0, 40);
       msg.data[i].username = decodeURIComponent(msg.data[i].username);

      //  msg.data[i].tipContent = msg.data[i].tipContent.substring(0, 40);

    }

    this.setData({
      commentListData: msg.data,
    });
    console.log("数据");
    console.log(this.data.commentListData);
    console.log(msg);
    var openid = wx.getStorageSync("openId");
    console.log(openid);
    
  },
  //回到顶部
  goTop: function(e) {
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },

  goLikes: function(e) {
    var userId = wx.getStorageSync("userId");
    var id = e.currentTarget.dataset.id;

    var param = {};
    param.userId = userId;
    param.contentId = id;

    app.getHttpData(param, this.data.addLike, this.goLikeCallback)

  },

  //点赞的回调
  goLikeCallback: function(msg) {

    if (msg.data.status == 1) {

      var tmp = [];

      for (var i = 0; i < this.data.commentListData.length; i++) {
        tmp[i] = this.data.commentListData[i];
        if (this.data.commentListData[i].id == msg.data.id) {
          tmp[i].likeNum = Math.abs(tmp[i].likeNum) + 1;
          tmp[i].hasLike = 1;
        }
      }

      this.setData({
        commentListData: tmp,
      });

      app.showToast("点赞成功");
    } else {
      app.showToast("你已经点赞过了");
    }
  },


  onGotUserInfo: function(e) {
    var that = this;
    //获取提示数据

    if (e.detail.errMsg == "getUserInfo:fail auth deny") {
      app.showToast("需要点击授权才可以开始互动~");
      return false;
    }
    
    if (e && e.detail.userInfo) {
      app.sendUserinfoData(e, this);
    }
  },

  // 点击跳转发布页
  clickSkipPublish: function() {
    var userId = wx.getStorageSync("userId");

    if (userId) {
      wx.navigateTo({
        url: "../comment/comment"
      })
    } else {
      app.showToast("请登录");
    }

  },
  onShow: function() {
    var param = {};
    param.userId = wx.getStorageSync("userId");
    app.getHttpData({}, this.data.communitList, this.getCommunityList);
    app.getHttpData(param, this.data.commentList, this.getCommentList);
    this.editUserinfo();
  }
})