const app = getApp();

//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: "", //传过来的文章id
    tit: "", //传过来的文章标题
    adjustPosition: false, //键盘弹起时，是否自动上推页面
    autoFocus: true, //自动聚焦，拉起键盘。
    cursorSpacing: 45, //指定光标与键盘的距离，单位 px 。取 textarea 距离底部的距离和 cursor-spacing 指定的距离的最小值作为光标与键盘的距离
    addComment: BASEURL + "addReplyByUser", //添加回复
  },

  /*
   *
   *修改传过来的数据
   */
  editData: function(e) {
    var id = e.id;
    var tit = e.title;
    this.setData({
      id: id, //传过来的文章id
      tit: tit, //传过来的文章标题
    });
  },

  //评论
  comment: function(e) {
    var inputValue = e.detail.value.textarea.replace(/(^\s*)|(\s*$)/g, "");
    var id = e.detail.target.dataset.id;

    if (!inputValue) {
      app.showToast("输入的内容不能为空");
      return false;
    }
  
    var param = {};
    param.contentId = id;
    param.from_uid = wx.getStorageSync("userId");
    param.content = encodeURIComponent(inputValue);

    app.getHttpData(param, this.data.addComment, this.commentCallback)
  },

 

  //评论回调
  commentCallback: function(msg) {

    if (msg.data.total > 1) {
      wx.setStorageSync("userAmount", msg.data.total);
    }
    if (msg.data.status == 1) {
      wx.redirectTo({
        url: '../../pages/article/article?contentId=' + msg.data.contentId,
      })
    } else {
      app.showToast(msg.data.msg);
    }
  },

  /*
   *
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;

    that.editData(options); //修改传过来的参数
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },


})