const app = getApp();

//获取请求后台基础url
const BASEURL = app.globalData.WXBaseUrl;
//背景图的基本路径
const BASEBACKGROUNDIMGURL = app.globalData.WXbackgroundImgUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    commentIsShow: "comment-isshow",
    userIsLogin: false,
    commentList: BASEURL + "getReplyById",
    commentListData: {}, //评论的数据
    addComment: BASEURL + "addReplyByUser", //添加回复
    addLike: BASEURL +"addLike",
    autoFocus: false,
    adjustPosition:false,//键盘弹起时，是否自动上推页面
    getShareDataUrl: BASEURL + "getShareContent", //获取分享数据的地址
    shareData: {},
    backgroundImgUrl: BASEBACKGROUNDIMGURL,//背景图的基本路径
  },

  // 结伴转发
  transpond: function (e) {
    this.onShareAppMessage();
  },

  //分享弹窗
  onShareAppMessage: function (param) {
    var that = this;
    var tit = that.data.shareData.title;
    var imgU = that.data.shareData.imgUrl;
  
    return {
      title: tit,
      // desc: '',
      path: '',
      imageUrl: imgU,
      success: function (msg) {
        var status = msg.errMsg;
    
        //分享成功
        var boolean = msg.hasOwnProperty('shareTickets');
        if (status == "shareAppMessage:ok" && boolean) {
          var param = {};
          var userId = wx.getStorageSync("userId"); //用户ID
          var id = "3";
          var random = Math.random();
          // param.sign=md5.h
          var signStr = that.md5Sign(userId, id, random);
          var sign = md5.hexMD5(signStr);
          param.sign = sign;
          param.id = id;
          param.userId = userId;
          param.random = random;
     
          app.showToast("分享成功");
          app.getHttpData(param, that.data.shareUrl, that.shareCallback);
        } else {
          // app.showToast("分享到群，才能完成任务哦")
        }
      },
      fail: function (msg) {
        console.log(msg)
      }
    }

  },

 
 //获取后台的分享数据
  Share:function(){
    var that = this;
    wx.request({
      url: that.data.getShareDataUrl,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {

        var title = res.data.title;
        var imgUrl = res.data.imgUrl;

        that.setData({
          shareData: {
            title: title,
            imgUrl: imgUrl
          }
        });
      }
    })
  },

  //分享回调数据更新状态
  shareCallback: function (msg) {

    if (msg.data.status == 1) {
      wx.setStorageSync("userAmount", msg.data.data);
      this.activityListStatus(msg.data.id);
    }
  },

  //修改用户的登录状态
  editUserinfo: function() {
    var userImg = wx.getStorageSync('userImg'); //获取用户头像
    var userName = wx.getStorageSync('userName'); //获取用户昵称
    var userAmount = wx.getStorageSync('userAmount'); //获取用户金币
    if (userName) {
      this.setData({
        userIsLogin: true
      });
    }

  },
  //授权
  onGotUserInfo: function(e) {
    if (e && e.detail.userInfo) {
      app.sendUserinfoData(e, this);
    }
  },

  goLikes: function (e) {
    var userId = wx.getStorageSync("userId");
    var id = e.currentTarget.dataset.id;

    var param = {};
    param.userId = userId;
    param.contentId = id;
    app.getHttpData(param, this.data.addLike, this.goLikeCallback)

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    that.editUserinfo(); //登录获取用户数据
    
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.showShareMenu({
      // shareTicket 是获取转发目标群信息的票据，只有拥有 shareTicket 才能拿到群信息，用户每次转发都会生成对应唯一的shareTicket 。
      withShareTicket: true
    });

    this.Share();
  
    var contentId = options.contentId;
    var param = {};
    param.id = contentId;
    param.userId = wx.getStorageSync("userId");

    app.getHttpData(param, this.data.commentList, this.getCommentConentById);

  },




  //点赞的回调
  goLikeCallback: function (msg) {

    if (msg.data.status == 1) {
      var likeNum = Math.abs(this.data.commentListData.likeNum)+1;


      var tmp = this.data.commentListData;
      tmp.likeNum = likeNum;
      tmp.hasLike=1;
      this.setData({
        commentListData:tmp,
      });

      app.showToast("点赞成功");
    } else {
      app.showToast("你已经点赞过了");
    }
  },

  getCommentConentById: function(msg) {
    console.log(999);
    console.log(msg);
    var commentListData = msg.data;

    if (commentListData.total>=1){
      wx.setStorageSync("userAmount", commentListData.total);
    }
    commentListData.tipContent = decodeURIComponent(msg.data.tipContent);
    commentListData.username = decodeURIComponent(commentListData.username); 
    for (var i = 0; i < commentListData.replyCon.length;i++){
      commentListData.replyCon[i].con = decodeURIComponent(commentListData.replyCon[i].con);
      commentListData.replyCon[i].from_name = decodeURIComponent(commentListData.replyCon[i].from_name);
    }
    this.setData({
      commentListData: commentListData,
    });


  },

  //图片点击事件
  imgYu: function (event) {
    var src = event.currentTarget.dataset.src;//获取data-src
   
    var imgList=[];
    var that = this;
    for (var i = 0; i < that.data.commentListData.contentImg.length;i++){
      imgList[i] = that.data.commentListData.contentImg[i].photo;
    }
  
    //图片预览
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: imgList  // 需要预览的图片http链接列表
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },



  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
    /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },



})